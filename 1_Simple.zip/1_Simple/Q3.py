# 3. Print Ascii Value of the Character

char = input("Enter character to know its ascii value ")

print(ord(char))