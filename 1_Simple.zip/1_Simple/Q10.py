# 10. The Display Size of the Different Datatype


print("""

The size of each datatype in Python 3.8 is as follows:

Size of int is: 12

Size of float is: 16

Size of str is: 25

Size of list is: 20

Size of tuple is: 12

Size of dict is: 120

Size of set is: 100

Size of frozenset is: 100

Size of None is: 8

Size of Ellipsis is: 8

Size of Object is: 8

Size of Lambda is: 60

Size of Function-ref is: 60

Size of Exception is: 32

""")

