#Converting Temperatture Celsius into Fahrenheit

celsius=float(input("Enter the temperature in celsius "))
far = (celsius * 1.8)+32
print(f"Temperature in fahrenheit is {far}")