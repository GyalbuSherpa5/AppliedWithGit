# 12. Read Integer (N) and Print the First Three Powers(N^1,
# N^2, N^3)

n = int(input("Enter integer n \n"))

print(n ** 1)
print(n ** 2)
print(n ** 3)
