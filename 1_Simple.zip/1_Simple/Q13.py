# 13. Area of a Circle

import math

radius = int(input("Enter radius "))

area = round(math.pi * (radius ^ 2), 2)
print("Area of circle is ", area)
