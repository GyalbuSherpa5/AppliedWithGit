# 4. Area of Triangle

base = int(input("Enter base "))
height = int(input("Enter height "))

print("Area of triangle is ", 1 / 2 * base * height)
