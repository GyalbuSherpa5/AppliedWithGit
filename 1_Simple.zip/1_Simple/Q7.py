# 7. Gross Salary of an Employee

salary = int(input("Enter your salary "))
vat = salary * 0.13
print("Your gross salary is ", salary + vat)
