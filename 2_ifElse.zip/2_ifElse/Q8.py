#8. Greatest of two numbers
a=int(input("Enter the first number"))
b=int(input("Enter te second number"))
if a>b:
    print(f"{a} is the greatest")
else:
    print(f"{b} is the greatest")