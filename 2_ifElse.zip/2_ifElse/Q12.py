# 12. Voting Eligibility Checker
age = int(input("Enter the age."))
if age >= 18:
    print("You are eligible to vote")
else:
    print("You are not eligible to vote")
