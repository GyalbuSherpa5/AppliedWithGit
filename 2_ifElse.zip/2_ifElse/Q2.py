# 2. The Number Is Positive or Negative

num = int(input("Enter number "))
if num >= 0:
    print("Number is positive")
else:
    print("Number is negative")
