#13. Find the maximum between two numbers.

a=int(input("Enter the first number"))
b=int(input("Enter te second number"))
if a>b:
    print(f"{a} is the maximun")
else:
    print(f"{b} is the maximum")