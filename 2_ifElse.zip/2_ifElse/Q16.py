# 16. Check whether a number is divisible by 5 and 11 or not.
num = int(input("Enter the number"))
if num % 5 == 0 and num % 11 == 0:
    print("The nuber is divisible by 5 and 11.")
else:
    print("The nuber is not divisible by 5 and 11.")
