#15. Check whether a number is negative, positive or zero.
num = int(input("Enter number "))
if num >0:
    print("Number is positive")
elif num==0:
    print("Number is zero")
else:
    print("Number is negative")