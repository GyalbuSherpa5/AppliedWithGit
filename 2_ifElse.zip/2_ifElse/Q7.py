#7. The Number Is Even or Odd
num = int(input("Enter number "))
if num%2==0:
    print("Number is even")
else:
    print("Number is odd")