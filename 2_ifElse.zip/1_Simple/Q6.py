# 6. Simple Interest

p = int(input("Enter principal "))
t = int(input("Enter time "))
r = float(input("Enter rate "))

print("Simple Interest is ", (p * t * r) / 100)
