# 8. Percentage of 5 Subjects

f = int(input("Enter mark of Science"))
s = int(input("Enter mark of Math"))
t = int(input("Enter mark of Social"))
u = int(input("Enter mark of EPH"))
v = int(input("Enter mark of English"))

p = ((f+s+t+u+v)/500)*100

print(int(p),"%")